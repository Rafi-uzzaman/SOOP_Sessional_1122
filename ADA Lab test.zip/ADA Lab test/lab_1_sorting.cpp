// Sorting Algorithms Performance Analysis
#include <bits/stdc++.h>
using namespace std;

void bubbleSort(vector<int>& a) {
    int n = a.size();
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (a[j] > a[j + 1])
                swap(a[j], a[j + 1]);
}

void insertionSort(vector<int>& a) {
    int n = a.size();
    for (int i = 1; i < n; i++) {
        int key = a[i], j = i - 1;
        while (j >= 0 && a[j] > key) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
}

void selectionSort(vector<int>& a) {
    int n = a.size();
    for (int i = 0; i < n - 1; i++) {
        int mn = i;
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[mn])
                mn = j;
        swap(a[i], a[mn]);
    }
}

void merge(vector<int>& a, int l, int m, int r) {
    int n1 = m - l + 1, n2 = r - m;
    vector<int> L(n1), R(n2);
    for (int i = 0; i < n1; i++) L[i] = a[l + i];
    for (int i = 0; i < n2; i++) R[i] = a[m + 1 + i];
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2)
        a[k++] = (L[i] <= R[j]) ? L[i++] : R[j++];
    while (i < n1) a[k++] = L[i++];
    while (j < n2) a[k++] = R[j++];
}

void mergeSort(vector<int>& a, int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        mergeSort(a, l, m);
        mergeSort(a, m + 1, r);
        merge(a, l, m, r);
    }
}

vector<int> randomArray(int n) {
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        a[i] = random() % n + 1;
    return a;
}

vector<int> increasingArray(int n) {
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        a[i] = i + 1;
    return a;
}

vector<int> decreasingArray(int n) {
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        a[i] = n - i;
    return a;
}

vector<int> uniformArray(int n) {
    return vector<int>(n, 5);
}

long long measure(void (*sortFunc)(vector<int>&), vector<int> a) {
    auto start = chrono::high_resolution_clock::now();
    sortFunc(a);
    auto end = chrono::high_resolution_clock::now();
    return chrono::duration_cast<chrono::microseconds>(end - start).count();
}

int main() {
    srand(time(0));
    vector<int> sizes = {100, 1000, 10000, 100000};

    for (int n : sizes) {
        vector<vector<int>> arrays = {
            randomArray(n),
            increasingArray(n),
            decreasingArray(n),
            uniformArray(n)
        };

        cout << "Array Size: " << n << endl;

        for (auto& arr : arrays) {
            cout << measure(bubbleSort, arr) << " ";
            cout << measure(insertionSort, arr) << " ";
            cout << measure(selectionSort, arr) << " ";
            auto a = arr;
            auto start = chrono::high_resolution_clock::now();
            mergeSort(a, 0, a.size() - 1);
            auto end = chrono::high_resolution_clock::now();
            cout << chrono::duration_cast<chrono::microseconds>(end - start).count() << endl;
        }
        cout << endl;
    }
    return 0;
}
