// Sum of Subset Using Backtracking

#include <bits/stdc++.h>
using namespace std;

int n, target;
vector<int> a;
vector<int> sel;

void solve(int i, int sum) {
    if (sum == target) {
        for (int j = 0; j < i; j++)
            if (sel[j]) cout << a[j] << " ";
        cout << endl;
        return;
    }
    if (i == n || sum > target) return;
    sel[i] = 1;
    solve(i + 1, sum + a[i]);
    sel[i] = 0;
    solve(i + 1, sum);
}

int main() {
    cin >> n;
    a.resize(n);
    sel.assign(n, 0);
    for (int i = 0; i < n; i++) cin >> a[i];
    cin >> target;
    solve(0, 0);
    return 0;
}
