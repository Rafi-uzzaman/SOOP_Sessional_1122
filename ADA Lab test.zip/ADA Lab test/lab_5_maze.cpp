// Maze Solver Using BFS

#include <bits/stdc++.h>
using namespace std;

int main() {
    int r, c;
    cin >> r >> c;
    vector<vector<int>> maze(r, vector<int>(c));
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            cin >> maze[i][j];

    int sx, sy, ex, ey;
    cin >> sx >> sy >> ex >> ey;

    vector<vector<int>> dist(r, vector<int>(c, -1));
    vector<vector<pair<int,int>>> parent(r, vector<pair<int,int>>(c, {-1, -1}));

    queue<pair<int,int>> q;
    q.push({sx, sy});
    dist[sx][sy] = 0;

    int dx[] = {1, -1, 0, 0};
    int dy[] = {0, 0, 1, -1};

    while (!q.empty()) {
        auto [x, y] = q.front();
        q.pop();
        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i], ny = y + dy[i];
            if (nx >= 0 && ny >= 0 && nx < r && ny < c && maze[nx][ny] == 0 && dist[nx][ny] == -1) {
                dist[nx][ny] = dist[x][y] + 1;
                parent[nx][ny] = {x, y};
                q.push({nx, ny});
            }
        }
    }

    if (dist[ex][ey] == -1) {
        cout << "No path";
        return 0;
    }

    cout << dist[ex][ey] << endl;

    vector<pair<int,int>> path;
    for (int x = ex, y = ey; x != -1; tie(x, y) = parent[x][y])
        path.push_back({x, y});

    reverse(path.begin(), path.end());
    for (auto p : path)
        cout << "(" << p.first << "," << p.second << ") ";

    return 0;
}
