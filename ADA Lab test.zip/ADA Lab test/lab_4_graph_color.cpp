// Graph Coloring Using Backtracking

#include <bits/stdc++.h>
using namespace std;

int n, m;
vector<vector<int>> g;
vector<int> color;

bool safe(int v, int c) {
    for (int i = 0; i < n; i++)
        if (g[v][i] && color[i] == c)
            return false;
    return true;
}

bool solve(int v) {
    if (v == n) return true;
    for (int c = 1; c <= m; c++) {
        if (safe(v, c)) {
            color[v] = c;
            if (solve(v + 1)) return true;
            color[v] = 0;
        }
    }
    return false;
}

int main() {
    cin >> n >> m;
    g.assign(n, vector<int>(n));
    color.assign(n, 0);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            cin >> g[i][j];
    if (solve(0))
        for (int i = 0; i < n; i++)
            cout << color[i] << " ";
    else
        cout << "No solution";
    return 0;
}
