// N-Queens Problem Using Backtracking

#include <bits/stdc++.h>
using namespace std;

int N;
vector<int> col;
long long solutions = 0;

bool safe(int r, int c) {
    for (int i = 0; i < r; i++)
        if (col[i] == c || abs(col[i] - c) == abs(i - r))
            return false;
    return true;
}

void solve(int r) {
    if (r == N) {
        solutions++;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++)
                cout << (col[i] == j ? "Q " : ". ");
            cout << endl;
        }
        cout << endl;
        return;
    }
    for (int c = 0; c < N; c++) {
        if (safe(r, c)) {
            col[r] = c;
            solve(r + 1);
        }
    }
}

int main() {
    cin >> N;
    col.resize(N);
    solve(0);
    cout << solutions << endl;
    return 0;
}
