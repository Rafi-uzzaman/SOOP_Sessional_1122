/*
 2. Convert a decimal number into correspondent binary number using recursion where decimal number is input from user.
 */

#include <stdio.h>
#include <stdlib.h>


int binary(int decimal_number)
{
    if (decimal_number == 0) return 0;
    return (decimal_number % 2 + 10 * binary(decimal_number / 2));
}

int main(){
    int n;
    printf("Enter the value of decimal number :: ");
    scanf("%d",&n);

    printf("Equivalent binary number :: %d", binary(n));

    return 0;
}
