/*
 1. The series 0, 1, 1, 2, 3, 5, 8, 13, … is called the Fibonacci series. Here, termn=termn-1 + termn-2, for n>1, term0 = 0, term1 = 1.
 Write a program that finds the sum of first n terms of the series using recursion.
 */

#include <stdio.h>
#include <stdlib.h>


int n;

int fibo(int x){
    if(x==0) return 0;
    if(x==1) return 1;
    return fibo(x-1)+fibo(x-2);
}

int sum(){
    int sum=0;
    for(int i=1;i<=n;i++){
        sum=sum+fibo(i);
    }
    return sum;
}

int main(){

    printf("Enter the value of n terms :: ");
    scanf("%d",&n);
    printf("Sum of the value of n terms ::  %d ",sum());

    return 0;
}