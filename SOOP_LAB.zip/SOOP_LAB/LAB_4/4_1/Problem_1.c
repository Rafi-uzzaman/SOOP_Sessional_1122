/*
1.	Write a multifunction program to print the following patterns where number of rows is user input and must be read in main function.
There should be separate function for each of the following patterns and note that,
 you cannot pass any data through parameters to those functions.

    (a)
4444444
33333
222
1

    (b)
7654321
54321
321
1

    (c)
* * * * *
* * *
*
* * *
* * * * *

*/


#include <stdio.h>
#include <stdlib.h>

int rows1,rows2,rows3;

void p1(){
    for(int r=(rows1);r>0;r--){
        for(int c=(r*2-1);c>0;c--){
            printf("%d",r);
        }
        printf("\n");
    }
}

void p2(){
    for(int r=(rows2);r>0;r--){
        for(int c=(r*2-1);c>0;c--){
            printf("%d",c);
        }
        printf("\n");
    }
}

void p3(){
    for(int r=-(rows3);r<=rows3;r+=2){
        for(int c=abs(r);c>0;c--){
            printf("* ");
        }
        printf("\n");
    }
}


int main(){

    printf("Enter the number of rows for pattern (a) :: ");
    scanf("%d", &rows1);
    p1();

    printf("Enter the number of rows for pattern (b) :: ");
    scanf("%d", &rows2);
    p2();

    printf("Enter the number of rows for pattern (c) :: ");
    scanf("%d", &rows3);
    p3();

    return 0;
}