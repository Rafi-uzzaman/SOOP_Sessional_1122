/*
2. Write a function to calculate the factorial value of any integer entered through the keyboard.
 */

#include <stdio.h>
#include <stdlib.h>

int n;

void fact(){
    int result=1;
    for(int i=1;i<=n;i++){
        result=result*i;
    }
    printf("Calculated factorial result :: %d ",result);
}

int main(){
    printf("Enter the value of any integer number ::  ");
    scanf("%d",&n);

    fact();

    return 0;
}