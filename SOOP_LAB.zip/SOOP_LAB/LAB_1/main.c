#include <stdio.h>

int main() {
    int n;
    scanf("%d",&n);
    printf("%d",~n);

    return 0;
}


////Problem: 01
//#include <stdio.h>
//
//int main() {
//    // Declare variables
//    int number;
//
//    // Input from the user
//    printf("Enter a number: ");
//    scanf("%d", &number);
//
//    // Calculate absolute value using ternary operator
//    int absoluteValue = (number >= 0) ? number : ~number+1;
//
//    // Output the result
//    printf("The absolute value of %d is %d\n", number, absoluteValue);
//
//    return 0;
//}


//Problem : 2
//#include <stdio.h>
//
//int main() {
//    // Declare variables
//    int num;
//
//    // User input
//    printf("Enter a number: ");
//    scanf("%d",&num);
//
//    // output process result
//    if( (num%5==0) && (num%7!=0)){
//        printf("YES");
//    }
//    else{
//        printf("NO");
//    }
//    return 0;
//}

// Problem : 3
//#include <stdio.h>
//
//int main() {
//    // variable declearation
//    char a,b,c;
//
//    //User Input
//    printf("Enter a 3 digit number: ");
//    scanf("%c %c %c",&a,&b,&c);
//
//    // Deccision
//    if(a<b && a<c){
//        printf("Minimum digit : %c",a);
//    }
//    else if(b<c){
//        printf("Minimum digit : %c",b);
//    }
//    else{
//        printf("Minimum digit : %c",c);
//    }
//    return 0;
//}

// problem : 4
//#include <stdio.h>
//
//int main() {
//    // variable declearation
//    double a,b,result;
//    char c;
//
//    // user input
//    printf("Enter your arithmetic operation : ");
//    scanf("%lf %c %lf",&a,&c,&b);
//
//    // Processing unit
//    switch (c) {
//        case '+':
//            result = a+b;
//            break;
//        case '-':
//            result = a-b;
//            break;
//        case '*':
//            result = a*b;
//            break;
//        case '/':
//            result = a/b;
//            break;
//        default:
//            break;
//    }
//
//    // output
//    printf("Your arithmetic operation result : %lf",result);
//
//    return 0;
//}


// Problem : 5
//#include <stdio.h>
//
//int main() {
//    // Variable declearation
//    char c;
//
//    // User input
//    printf("Input your grade : ");
//    scanf("%c",&c);
//
//    // Processing & Output unit
//    switch (c) {
//        case 'A':
//            printf("Your grade percentage : 80-100%%");
//            break;
//        case 'B':
//            printf("Your grade percentage : 70-79%%");
//            break;
//        case 'C':
//            printf("Your grade percentage : 60-69%%");
//            break;
//        case 'D':
//            printf("Your grade percentage : 50-59%%");
//            break;
//        case 'F':
//            printf("Your grade percentage : 0-50%%");
//            break;
//        default:
//            printf("Your grade percentage : Invalid grade");
//            break;
//
//    }
//    return 0;
//}


// Problem : 6
//#include <stdio.h>
//
//int main() {
//    // Variable declearation
//    float unit,price=0;
//
//    // User input
//    printf("Input number of units : ");
//    scanf("%f",&unit);
//
//    // Processing unit
//    if(unit>100){
//        price=(unit-100)*1;
//        unit=unit-(unit-100);
//    }
//    if(unit>80){
//        price+=(unit-80)*2;
//        unit=unit-(unit-80);
//
//    }
//    if(unit>50){
//        price+=(unit-50)*3;
//        unit=unit-(unit-50);
//    }
//
//    price+=unit*4;
//
//    //output unit
//    printf("Monthly electricity bill : BDT %.1f only",price);
//
//    return 0;
//}