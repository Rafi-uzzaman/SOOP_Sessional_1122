//5. Using pointer arithmetic,
//a. Write a C program to take input and print elements of an array.
//b. Write a C program to copy one array to another.
//c. Write a program to search for an element in an array.
//d. Write a program to print the reverse of a string.
//

//d. Write a program to print the reverse of a string.
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>


int main(){
    char str[255];
    printf("Write a string :: ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")] = '\0';

    char *start = str;
    char *end = str+strlen(str)-1;

    printf("Reversed string :: ");
    while (start<=end){
        printf("%c",*end);
        end--;
    }

    return 0;
}