
//5. Using pointer arithmetic,
//a. Write a C program to take input and print elements of an array.
//b. Write a C program to copy one array to another.
//c. Write a program to search for an element in an array.
//d. Write a program to print the reverse of a string.
//

//b. Write a C program to copy one array to another.
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

int main(){
    int size;
    printf("Enter the size of array :: ");
    scanf("%d", &size);

    int arr1[size];
    int arr2[size];
    printf("Enter %d integers ::\n", size);
    for(int i=0;i<size;i++){
        scanf("%d", & arr1[i]);
    }

    int *ptr1= arr1;
    int *ptr2=arr2;
    for(int i=0;i<size;i++){
        *ptr2++ = *ptr1++;
    }

    printf("Elements of entered array :: \n");
    for(int i=0;i<size;i++){
        printf("%d ",arr1[i]);
    }
    printf("\n");

    printf("Elements of copy array :: \n");
    for(int i=0;i<size;i++){
        printf("%d ",arr2[i]);
    }




    return 0;
}