//5. Using pointer arithmetic,
//a. Write a C program to take input and print elements of an array.
//b. Write a C program to copy one array to another.
//c. Write a program to search for an element in an array.
//d. Write a program to print the reverse of a string.
//

//c. Write a program to search for an element in an array.
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

int main(){

    int size,search_element,found=0;
    printf("Enter the size of array :: ");
    scanf("%d", &size);

    int arr[size];
    printf("Enter %d integers ::\n", size);
    for(int i=0;i<size;i++){
        scanf("%d", & arr[i]);
    }
    printf("Enter search element from array :: ");
    scanf("%d", &search_element);

    int *ptr=arr;
    for(int i=0;i<size;i++){
        if(*ptr==search_element){
            printf("Element %d found at index %d\n",search_element, i);
            found=1;
            break;
        }
        ptr++;
    }
    if(!found){
        printf("Element %d not found in the array\n", search_element);
    }


    return 0;
}