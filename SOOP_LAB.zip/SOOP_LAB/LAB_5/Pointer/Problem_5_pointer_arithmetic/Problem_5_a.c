//
//
//5. Using pointer arithmetic,
//a. Write a C program to take input and print elements of an array.
//b. Write a C program to copy one array to another.
//c. Write a program to search for an element in an array.
//d. Write a program to print the reverse of a string.
//

//a.Write a C program to take input and print elements of an array.
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

int main(){

    int num_elements;

    printf("Enter the number of elements: ");
    scanf("%d", &num_elements);

    if (num_elements <= 0) {
        printf("Invalid input: Number of elements must be positive.\n");
        return 1;
    }

    int *arr = (int *)malloc(num_elements * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    printf("Enter %d integers:\n", num_elements);
    int *ptr = arr;
    for (int i = 0; i < num_elements; i++) {
        scanf("%d", ptr++);
    }

    printf("Entered elements:\n");
    ptr = arr;
    for (int i = 0; i < num_elements; i++) {
        printf("%d ", *ptr++);
    }
    printf("\n");
    free(arr);

    return 0;
}