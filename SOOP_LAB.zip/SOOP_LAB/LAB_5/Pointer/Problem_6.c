//
// 6. Write a function that to swaps two numbers using pointers.
//

#include <stdio.h>

void fun(int *x, int *y){
    int temp = *x;
    *x = *y;
    *y=temp;
    return;
}

int main(){
    int a,b;
    printf("Write two number as input :: ");
    scanf("%d %d", &a, &b);
    fun(&a,&b);
    printf("After swaps two numbers using pointers are :: %d %d ",a,b);


    return 0;
}