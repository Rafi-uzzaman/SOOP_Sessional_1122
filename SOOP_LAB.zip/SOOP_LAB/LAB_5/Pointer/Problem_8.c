//
// 8. Write a program to dynamically allocate a two dimensional (m*n) array. Take the dimensions m and n as input.
//

#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

int main(){

    int n,m;

    printf("Enter the number of row and column :: ");
    scanf("%d %d", &m , &n);

    if (n <= 0 || m<=0) {
        printf("Invalid input: Number of elements must be positive.\n");
        return 1;
    }
    int (*arr)[n]= (int *)malloc(m * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    printf("Input two dimensional array :: \n");
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            scanf("%d", & arr[i][j]);
        }
    }
    printf("\n");
    printf("Output of two dimensional array :: \n");
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            printf("%d ", *(*(arr+i)+j));
        }
        printf("\n");
    }


    free(arr);
    return 0;
}