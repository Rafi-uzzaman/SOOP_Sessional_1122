//
// 2. Write down a program that will take a word as input and will determine whether the word is palindrome or not.
//

#include <stdio.h>
#include <strings.h>

int main(){
    char str[255];
    int size;
    printf("Write a word :: ");
    scanf("%s",&str);

    size = strlen(str);
    int j=(size-1),flag=0;
    for(int i=0;i<size;i++){
        if(str[i]!=str[j]){
            flag++;
            break;
        }
        j--;
    }
    if(flag>0){
        printf("The word is not palindrome.");
    }
    else{
        printf("The word is palindrome.");
    }

    return 0;
}