//
//1. Write a program in C which will take a string as input and count total number of alphabets,
// digits and special characters in a string.
//


#include <stdio.h>
#include <strings.h>

int main() {

    char str[255];
    int count_ap=0,count_di=0,count_sp=0,size;

    printf("Write a string :: ");
    scanf("%s", &str);

    size= strlen(str);
    for(int i=0;i<size;i++){
        if((str[i]>='A' && str[i]<='Z') || (str[i]>='a' && str[i]<='z')){
            count_ap++;
        }
        else if((str[i]>='0' && str[i]<='9')){
            count_di++;
        }
        else{
            count_sp++;
        }
    }
    printf("Total number of alphabets :: %d \n",count_ap);
    printf("Total number of digits :: %d \n",count_di);
    printf("Total number of special characters  :: %d \n",count_sp);

    return 0;
}
