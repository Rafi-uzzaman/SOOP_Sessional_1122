//
// 3. Write down a function that compares two strings and returns 1 if they are same and returns 0 otherwise.
//

#include <stdio.h>
#include <strings.h>
#include <math.h>

char str1[255],str2[255];

int fun(){
    int size=fmax(strlen(str1), strlen(str2));
    for(int i=0;i<size;i++){
        if(str1[i]!=str2[i]){
            return 0;
        }
    }
    return 1;
}

int main(){

    printf("Write down first string :: ");
    scanf("%s", &str1);

    printf("Write down second string :: ");
    scanf("%s", &str2);

    if(fun()==1){
        printf("They are same.");
    }
    else{
        printf("They are not same.");
    }

    return 0;
}
