//
// Write a C program to check whether a given substring is present in the given string.
// Enter a string: This is a test string.
//Enter substring: string
//Expected Output: ‘string’ exists as a substring in the string.
//This is a test string.

#include <stdio.h>
#include <string.h>

int main(){
    char str[255], sub[255];

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    str[strcspn(str, "\n")] = '\0';

    printf("Enter substring: ");
    fgets(sub, sizeof(sub), stdin);
    sub[strcspn(sub, "\n")] = '\0';

    if (strstr(str, sub) != NULL) {
        printf("'%s' exists as a substring in the string.\n", sub);
    } else {
        printf("'%s' does not exist as a substring in the string.\n", sub);
    }

    return 0;
}