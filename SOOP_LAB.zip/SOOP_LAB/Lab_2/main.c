//program:01
//#include <stdio.h>
//
//int main() {
//    int sum=0,n,avg;
//    printf("Enter the value of n :: ");
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        sum=sum+((2*i)-1);
//    }
//    printf("The sum of first n odd natural numbers  :: %d\n",sum);
//    avg=(sum/n);
//    printf("The average of first n odd natural numbers :: %d",avg);
//    return 0;
//}



// //program : 02
//#include <stdio.h>
//
//int main() {
//
//    int prev = 15, current;
//    char choice;
//
//    do {
//        printf("Enter an integer: ");
//        scanf("%d", &current);
//
//        if (current > prev)
//            printf("It is greater than %d.\n", prev);
//        else if (current < prev)
//            printf("It is less than %d.\n", prev);
//        else
//            printf("It is equal to %d.\n", prev);
//
//        printf("Do you want to continue (y/n)? ");
//        scanf(" %c", &choice);
//
//        prev = current;
//
//    } while (choice == 'y');
//
//    return 0;
//}
//
//
//// program: 3
// #include <stdio.h>
//
//int main() {
//     int num, reversed = 0, original;
//
//    printf("Enter an integer: ");
//    scanf("%d", &num);
//
//    original = num;
//
//    while (num != 0) {
//        reversed = reversed * 10 + num % 10;
//        num /= 10;
//    }
//
//    if (original == reversed)
//        printf("%d is a palindrome.\n", original);
//    else
//        printf("%d is not a palindrome.\n", original);
//    return 0;
//}
//
//
//
////program :4 i
//#include <stdio.h>
//
//int main() {
//    int n,x;
//    double sum=0,st=2;
//    printf("Enter the value of x :: ");
//    scanf("%d", &x);
//    printf("Enter the value of n :: ");
//    scanf("%d", &n);
//
//    for(int i=1;i<=n;i++){
//        double fact=1,po=1;
//        for(int j=1;j<=st;j++){
//            po=po*x;
//        }
//
//        for(int j=1;j<=st;j++){
//            fact=fact*j;
//        }
//
//        st++;
//
//        if(i%3==0){
//            sum=sum-(po/fact);
//        }
//        else{
//            sum=sum+(po/fact);
//        }
//    }
//    printf("The sum of the series up to %d terms :: %.3f",n,sum);
//    return 0;
//}
//
// //program: 4.ii
//#include <stdio.h>
//
//int main() {
//    int n, r, sum = 0, t;
//    printf("Enter the value of n :: ");
//    scanf("%d", &n);
//    for (int i=1;i<=n;i++){
//        for(int j=1;j<=i;j++){
//            sum=sum+j;
//        }
//    }
//    printf("The sum of the series up to %d terms :: %d",n,sum);
//    return 0;
//}
//// program: 5
// #include <stdio.h>
//
//
//
//int main() {
//
//    int num, i, flag, st, ed;
//
//    printf("Input starting number of range: ");
//    scanf("%d", &st);
//
//    printf("Input ending number of range : ");
//    scanf("%d", &ed);
//
//    printf("The prime numbers between %d and %d are :: ", st, ed);
//    for (num = st; num <= ed; num++) {
//        flag = 0;
//        for (i = 2; i <= num / 2; i++) {
//            if (num % i == 0) {
//                flag++;
//                break;
//            }
//        }
//        if (flag == 0 && num != 1)
//            printf("%d ", num);
//    }
//    return 0;
//}
//
//
//
////program: 6
//#include <stdio.h>
//
//int main() {
//    int num1, num2, num3, gcd=1, flag=0, count, lcm;
//
//    printf("Enter 1st positive integer :: ");
//    scanf("%d",&num1);
//    printf("Enter 2nd positive integer :: ");
//    scanf("%d",&num2);
//    printf("Enter 3rd positive integer :: ");
//    scanf("%d",&num3);
//
//    if(num1==0 && num2==0 && num3==0)
//    {
//        printf("Invalid number");
//    }
//    else{
//        for(count=1; flag==0;count++)
//        {
//            if(num1%count==0 && num2%count==0 && num3%count==0)
//                gcd=count;
//            if(count>num1 && count>num2 && count>num3)
//            {
//                flag=1;
//            }
//        }
//        printf("GCD of [ %d, %d, %d ] is :: %d \n",num1,num2,num3,gcd);
//    }
//
//    for(int i=1 ; ; i++)
//    {
//        if(i%num1==0 && i%num2==0 && i%num3==0)
//        {
//            lcm = i;
//            break;
//        }
//    }
//    printf("LCM of [ %d, %d, %d ] is :: %d \n",num1,num2,num3,lcm);
//
//    return 0;
//}
//
//
// //program: 7
// #include <stdio.h>
//
//
//
//int main() {
//
//    int n,sum1=0;
//    printf("Enter the positive value of n :: ");
//    scanf("%d", &n);
//
//    for(int i=1;i<=n;i++){
//        sum1=sum1+((i+1)*(i+2));
//    }
//    int i=1,sum2=0;
//    while (i<=n){
//        sum2=sum2+((i+1)*(i+2));
//        i++;
//    }
//    if(1==1){
//        printf("Verified, Both are Equal");
//    }
//    else{
//        printf("Invalid Program");
//    }
//
//
//    return 0;
//}
//
// //program :08
//#include <stdio.h>
//
//int main() {
//
//    int n,a=0,b=1,x;
//    printf("Enter the value of n :: ");
//    scanf("%d", &n);
//    printf("Fibonacci Series :: %d, %d", a, b);
//    for(int i=1;i<=(n-2);i++){
//        x=a;
//        a=b;
//        b=x+a;
//        printf(", %d", b);
//    }
//    return 0;
//}

