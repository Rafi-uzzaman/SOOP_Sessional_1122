//#include <stdio.h>
//
//int main() {
//
//    int size = 0,temp,k,ls;
//    printf("Enter the size of array :");
//    scanf("%d",&size);
//    int arr[size];
//    printf("Input the element of array :");
//    for(int i=0;i<size;i++){
//        scanf("%d",&arr[i]);
//    }
//    printf("Enter the value of k : ");
//    scanf("%d",&k);
//    for(int i=0;i<size-1;i++){
//        for(int j=0;j<size-i-1;j++){
//            if(arr[j]>arr[j+1]){
//                temp=arr[j];
//                arr[j]=arr[j+1];
//                arr[j+1]=temp;
//            }
//        }
//    }
//     ls= 0;
//    for (int i = 0; i < size - 1; i++) {
//        if (arr[i] != arr[i + 1]) {
//            arr[ls++] = arr[i];
//        }
//    }
//    arr[ls++] = arr[size - 1];
//
//    printf("%dth maximum value from an array : %d \n",k,arr[ls-k]);
//    printf("%dth minimum value from an array : %d",k,arr[k-1]);
//
//    return 0;
//}
//lab practice:
//#include <stdio.h>
//
//int main() {
//sum of sum:
//int n,sum=0;
//    printf("Enter the value of n :");
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=1;j<=i;j++){
//            sum=sum+j;
//        }
//    }
//    printf("Sum of sum of the series total sum of %d terms :: %d ", n,sum);
// return 0;
//}

//Prime number:
//lab practice:
//#include <stdio.h>
//
//int main() {
//
//int a,b,count;
//    printf("Enter a first value of range :");
//    scanf("%d",&a);
//    printf("Enter a last value of range :");
//    scanf("%d",&b);
//    printf("Prime number of range %d to %d is :: ",a,b);
//    for(int i=a;i<=b;i++){
//        count=0;
//        int j=2;
//        while(j<=(i/2)){
//            if(i%j==0){
//                count++;
//            }
//            j++;
//        }
//
//        if(i!=1 && count==0){
//            printf("%d ",i);
//        }
//
//    }
// return 0;
//}

//Floating point number :
//#include <stdio.h>
//
//int main() {
//int numCount;
//    float num, max = -1000000, min = 1000000, sum = 0, average;
//
//    printf("Enter the number of floating-point numbers: ");
//    scanf("%d", &numCount);
//
//    printf("Enter the numbers:\n");
//    for (int i = 1; i <= numCount; i++) {
//        scanf("%f", &num);
//
//        if (num > max) {
//            max = num;
//        }
//
//        if (num < min) {
//            min = num;
//        }
//
//        sum += num;
//    }
//
//    average = sum / numCount;
//
//    printf("\nMaximum number: %.2f\n", max);
//    printf("Minimum number: %.2f\n", min);
//    printf("Average: %.2f\n", average);
// return 0;
//}


// insert data

//#include <stdio.h>
//
//int main() {
//int arr[5],loca,data;
//    printf("Enter 5 integers :: ");
//    for(int i=0;i<5;i++){
//        scanf("%d",&arr[i]);
//    }
//    printf("Enter data to insert in the list :: ");
//    scanf("%d",&data);
//    printf("Enter location to insert at :: ");
//    scanf("%d",&loca);
//    printf("List before insertion of new data :: ");
//    for(int i=0;i<5;i++){
//        printf("%d ",arr[i]);
//    }
//    for(int i=5;i>=loca;i--){
//        arr[i]=arr[i-1];
//    }
//    arr[loca-1]=data;
//    printf("\nList after insertion of new data :: ");
//    for(int i=0;i<=5;i++){
//        printf("%d ",arr[i]);
//    }
// return 0;
//}

//Home Assignment 3:
// 1.
//a

//#include <stdio.h>
//
//int main() {
//int n;
//    printf("Enter the value of n : ");
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        for(int j=1;j<=i;j++){
//            printf("* ");
//        }
//        printf("\n");
//    }
// return 0;
//}

//b.

//#include <stdio.h>
//
//int main() {
//int n;
//    char c;
//    printf("Enter the value of n : ");
//    scanf("%d",&n);
//    for(int i=1;i<=n;i++){
//        c='a';
//        for(int j=1;j<=i;j++){
//            printf("%c",c);
//            c++;
//        }
//        c--;
//        printf(" ");
//        for(int j=1;j<=i;j++){
//            printf("%c",c);
//        }
//        printf("\n");
//    }
// return 0;
//}

// 2. number to word
//#include <stdio.h>
//
//int main() {
//int n,in;
//    printf("How many time repeat this process :: ");
//    scanf("%d",&in);
//    while(in--){
//        printf("Enter an integer [20-99]: ");
//        scanf("%d",&n);
//        printf("In words: ");
//        if(n>=20 && n<=99){
//            switch (n/10) {
//                case 2:
//                {
//                    printf("Twenty ");
//                    break;
//                }
//                case 3:
//                {
//                    printf("Thirty ");
//                    break;
//                }
//                case 4:
//                {
//                    printf("Forty ");
//                    break;
//                }
//                case 5:
//                {
//                    printf("Fifty ");
//                    break;
//                }
//                case 6:
//                {
//                    printf("Sixty ");
//                    break;
//                }
//                case 7:
//                {
//                    printf("Seventy ");
//                    break;
//                }
//                case 8:
//                {
//                    printf("Eighty ");
//                    break;
//                }
//                case 9:
//                {
//                    printf("Ninety ");
//                    break;
//                }
//                default:
//                    break;
//            }
//
//
//            switch (n%10) {
//                case 0:
//                {
//                    printf("\n");
//                    break;
//                }
//                case 1:
//                {
//                    printf("One\n");
//                    break;
//                }
//                case 2:
//                {
//                    printf("Tow\n");
//                    break;
//                }
//                case 3:
//                {
//                    printf("Three\n");
//                    break;
//                }
//                case 4:
//                {
//                    printf("Four\n");
//                    break;
//                }
//                case 5:
//                {
//                    printf("Five\n");
//                    break;
//                }
//                case 6:
//                {
//                    printf("Six\n");
//                    break;
//                }
//                case 7:
//                {
//                    printf("Seven\n");
//                    break;
//                }
//                case 8:
//                {
//                    printf("Eight\n");
//                    break;
//                }
//                case 9:
//                {
//                    printf("Nine\n");
//                    break;
//                }
//                default:
//                    break;
//            }
//
//        }
//    }
// return 0;
//}

// 3. delete duplicate items
//#include <stdio.h>
//
//int main() {
//    int arr[100], i, j, k, size;
//    printf("Enter the size of the array: ");
//    scanf("%d", &size);
//    printf("Enter the elements of the array: ");
//    for (i = 0; i < size; i++) {
//        scanf("%d", &arr[i]);
//    }
//    for (i = 0; i < size - 1; i++) {
//        for (j = 0; j < size - i - 1; j++) {
//            if (arr[j] > arr[j + 1]) {
//                k = arr[j];
//                arr[j] = arr[j + 1];
//                arr[j + 1] = k;
//            }
//        }
//    }
//    k = 0;
//    for (i = 0; i < size - 1; i++) {
//        if (arr[i] != arr[i + 1]) {
//            arr[k++] = arr[i];
//        }
//    }
//    arr[k++] = arr[size - 1];
//    printf("Array after removing duplicates: ");
//    for (i = 0; i < k; i++) {
//        printf("%d ", arr[i]);
//    }
//    return 0;
//}


// 4.
//#include <stdio.h>
//
//int main() {
//
//    int size = 0,temp,k,ls;
//    printf("Enter the size of array :");
//    scanf("%d",&size);
//    int arr[size];
//    printf("Input the element of array :");
//    for(int i=0;i<size;i++){
//        scanf("%d",&arr[i]);
//    }
//    printf("Enter the value of k : ");
//    scanf("%d",&k);
//    for(int i=0;i<size-1;i++){
//        for(int j=0;j<size-i-1;j++){
//            if(arr[j]>arr[j+1]){
//                temp=arr[j];
//                arr[j]=arr[j+1];
//                arr[j+1]=temp;
//            }
//        }
//    }
//     ls= 0;
//    for (int i = 0; i < size - 1; i++) {
//        if (arr[i] != arr[i + 1]) {
//            arr[ls++] = arr[i];
//        }
//    }
//    arr[ls++] = arr[size - 1];
//
//    printf("%dth maximum value from an array : %d \n",k,arr[ls-k]);
//    printf("%dth minimum value from an array : %d",k,arr[k-1]);
//
//    return 0;
//}


//5. merge array
#include <stdio.h>

int main() {

    int arr1[]={1, 3, 5, 7};
    int arr2[]={2, 4, 6, 8, 10};
    int size =(sizeof (arr1)/sizeof(arr1[0]))+(sizeof(arr2)/sizeof(arr2[0]));
    int merge_array[size];
    int a=0,b=0,k;
    for(int i=0;i<size;i++){
        if(i%2==0){
            merge_array[i]=arr1[a++];
        }
        else{
            merge_array[i]=arr2[b++];
        }
    }

    printf("Merge two sorted arrays in one arrays :: ");
    for(int i=0;i<size-1;i++){
        printf("%d ",merge_array[i]);
    }
    return 0;
}
